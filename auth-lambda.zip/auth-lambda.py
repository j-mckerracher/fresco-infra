import json
import os
import jwt
import time


def lambda_handler(event, context):
    path = event.get('rawPath', '')
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')

    if path == '/ws-url' and method == 'GET':
        return ws_url_handler(event)
    elif path == '/get-jwt' and method == 'POST':
        return generate_jwt_handler(event)
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Not Found'})
        }


def ws_url_handler(event):
    websocket_url = f"wss://{os.environ['WEBSOCKET_API_ID']}.execute-api.{os.environ['REGION']}.amazonaws.com/{os.environ['WEBSOCKET_STAGE']}"
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps({'websocket_url': websocket_url})
    }


def generate_jwt_handler(event):
    body = json.loads(event.get('body', '{}'))
    client_id = body.get('clientId')

    if not client_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing clientId'})
        }

    token = generate_jwt(client_id)
    return {
        'statusCode': 200,
        'body': json.dumps({'token': token})
    }


def generate_jwt(client_id: str) -> str:
    payload = {
        'clientId': client_id,
        'iss': os.environ['JWT_ISSUER'],
        'exp': int(time.time()) + 3600  # Expires in 1 hour
    }
    token = jwt.encode(payload, os.environ['JWT_SECRET'], algorithm='HS256')
    return token
